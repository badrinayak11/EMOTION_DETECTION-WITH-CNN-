INSTALL ALL NECESSARY DATASET

DATASET_LINK1: https://www.kaggle.com/datasets/uwrfkaggler/ravdess-emotional-speech-audio
DATASET_LINK2: https://www.kaggle.com/datasets/ejlok1/toronto-emotional-speech-set-tess

### ACCURACY
![output](https://github.com/user-attachments/assets/4386177c-c1c0-4822-ac58-d737474dc6d2)
